#include <iostream>
#include <fstream>
using namespace std;

void main(int argc, char** argv)
{
	unsigned int	address;
	unsigned int	instruction[4];
	unsigned int	temp;
	unsigned int	Btemp[32];
	char			select;
	char			strTemp[50];

	FILE		*IN_FILE;
	ofstream	OUT_FILE("mins.prog", ios::out);
	IN_FILE = fopen("mins.txt", "r");

	if(IN_FILE == NULL) {
		cerr << "mins.txt could not be opened!" << endl;
		system("PAUSE");
		exit(0);
	}

	cout << "Please select b(binary) or h(hexadecimal) : ";
	cin >> select;
	if(select != 'b' && select != 'h') {
		cout << "Wrong select!" << endl;
		system("PAUSE");
		exit(0);
	}

	if(fgets(strTemp, 50, IN_FILE) != NULL)
		cout << "Monitor " << strTemp;
	if(fgets(strTemp, 50, IN_FILE) != NULL)
		cout << strTemp << endl;

	while((fscanf(IN_FILE, "%X %X %X %X %X", &address, &instruction[0], &instruction[1], &instruction[2], &instruction[3])) != EOF) {
		cout << hex << "  " << address << "  " << instruction[0] << "  " << instruction[1] << "  " << instruction[2] << "  " << instruction[3] << endl;
		for(unsigned int i = 0; i < 4; i++) {
			OUT_FILE << "@" << hex << (address + i * 4) << endl;
			if(select == 'b') {
				temp = instruction[i];
				for(unsigned int j = 0; j < 32; j++) {
					Btemp[31 - j] = temp % 2;
					temp = temp / 2;
				}
				for(unsigned int j = 0; j < 32; j++) {
					if(j%4 ==0 && j != 0)
						OUT_FILE << "_";
					OUT_FILE << Btemp[j];
				}
			} else {
				OUT_FILE << hex << instruction[i];
			}
			OUT_FILE << endl;
		}
	}
	
	fclose(IN_FILE);
	system("PAUSE");
}
